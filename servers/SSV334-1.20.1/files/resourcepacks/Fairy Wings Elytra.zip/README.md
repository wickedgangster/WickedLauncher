# Fairy Wings Elytra
Fly high with fluttering opalescent fairy wings. Created by Kchem and Garden Gals.
CC-BY-NC-SA-4.0
https://discord.gg/H9V6FuVGfT
https://modrinth.com/organization/garden-gals